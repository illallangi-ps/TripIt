# https://oauth.net/core/1.0/

#region 9.1.1 Normalize Request Parameters (Get-NormalizedRequestParameters)

function Get-RequestParameters
{
    [CmdletBinding()]
    param
    (
        [Parameter(Mandatory=$true)]
        [Hashtable]$OAuth,

        [Parameter(Mandatory=$true)]
        [Hashtable]$Args
    )

    BEGIN
    {
        $requestParameters=@{}
        foreach ($key in $OAuth.Keys |?{ !$_.ToLower().EndsWith("_secret") })
        {
            $requestParameters.Add("oauth_$($key.ToLower())", $OAuth[$key])
        }
        foreach ($key in $Args.Keys |?{ !$_.ToLower().EndsWith("_secret") })
        {
            $requestParameters.Add("$($key.ToLower())", $Args[$key])
        }
        
        $requestParameters
    }
}

function Normalize-RequestParameters
{
    [CmdletBinding()]
    param
    (
        [Parameter(Mandatory=$true, ValueFromPipelineByPropertyName=$true)]
        [string]$Name,

        [Parameter(Mandatory=$true, ValueFromPipelineByPropertyName=$true)]
        [string]$Value
    )

    BEGIN
    {
        $parameters=@{}
    }

    PROCESS
    {
        $parameters.Add($Name, $Value)
    }

    END
    {
        [String]::Join("&", ($parameters.Keys | Sort-Object |%{ "$($_)=$($parameters["$($_)"])" }))
    }
}

function Get-NormalizedRequestParameters
{
    [CmdletBinding()]
    param
    (
        [Parameter(Mandatory=$true, ParameterSetName='HashTables')]
        [Hashtable]$OAuth,

        [Parameter(Mandatory=$true, ParameterSetName='HashTables')]
        [Hashtable]$Args
    )

    BEGIN
    {
        switch ($PSCmdlet.ParameterSetName)
        {
            "HashTables"
            {
                $getRequestParametersArgs=@{
                        OAuth=$OAuth;
                        Args=$Args;
                    }
                ((Get-RequestParameters @getRequestParametersArgs).GetEnumerator() | Normalize-RequestParameters)
        
            }
        }
    }
}

#endregion

#region 9.1.3 Concatenate Request Elements (Get-SignatureBaseString)

function Get-SignatureBaseString
{
    [CmdletBinding()]
    param
    (
        [Parameter(Mandatory=$true, ParameterSetName='HashTables')]
        [Hashtable]$OAuth,

        [Parameter(Mandatory=$true, ParameterSetName='HashTables')]
        [Hashtable]$Args,
        
        [Parameter(Mandatory=$true, ParameterSetName='Normalized')]
        [string]$NormalizedRequestParameters,

        [Parameter(Mandatory=$true, ParameterSetName='HashTables')]
        [Parameter(Mandatory=$true, ParameterSetName='Normalized')]
        [uri]$Uri,

        [Parameter(Mandatory=$true, ParameterSetName='HashTables')]
        [Parameter(Mandatory=$true, ParameterSetName='Normalized')]
        [Microsoft.PowerShell.Commands.WebRequestMethod]$Method
    )

    BEGIN
    {
        switch ($PSCmdlet.ParameterSetName)
        {
            "HashTables"
            {
                $getNormalizedRequestParametersArgs=@{
                        OAuth=$OAuth;
                        Args=$Args;
                    }
                $normalizedRequestParameters=Get-NormalizedRequestParameters @getNormalizedRequestParametersArgs

                $getSignatureBaseStringArgs=@{
                        NormalizedRequestParameters=$normalizedRequestParameters;
                        Uri=$Uri;
                        Method=$Method;
                    }
                Get-SignatureBaseString @getSignatureBaseStringArgs
            }

            "Normalized"
            {
                $signatureBaseString = [string]::Join(
                        "&",
                        (@(
                            "$($Method.ToString().ToUpper())",
                            "$($Uri.GetLeftPart("Path"))",
                            "$($NormalizedRequestParameters)"
                        ) |%{ [uri]::EscapeDataString($_) })
                    )
                $signatureBaseString
            }
        }
    }
}

#endregion

#region 9.2 HMAC-SHA1

function Get-HmacSha1Signature
{
    [CmdletBinding()]
    param
    (
        [Parameter(Mandatory=$true, ParameterSetName='HashTables')]
        [Hashtable]$OAuth,

        [Parameter(Mandatory=$true, ParameterSetName='HashTables')]
        [Hashtable]$Args,
        
        [Parameter(Mandatory=$true, ParameterSetName='Normalized')]
        [string]$NormalizedRequestParameters,

        [Parameter(Mandatory=$true, ParameterSetName='HashTables')]
        [Parameter(Mandatory=$true, ParameterSetName='Normalized')]
        [uri]$Uri,

        [Parameter(Mandatory=$true, ParameterSetName='HashTables')]
        [Parameter(Mandatory=$true, ParameterSetName='Normalized')]
        [Microsoft.PowerShell.Commands.WebRequestMethod]$Method,

        [Parameter(Mandatory=$true, ParameterSetName='BaseString')]
        [string]$SignatureBaseString,

        [Parameter(Mandatory=$true, ParameterSetName='BaseString')]
        [Parameter(Mandatory=$true, ParameterSetName='Normalized')]
        [string]$ConsumerSecret,

        [Parameter(Mandatory=$true, ParameterSetName='BaseString')]
        [Parameter(Mandatory=$true, ParameterSetName='Normalized')]
        [AllowEmptyString()]
        [string]$TokenSecret
    )

    BEGIN
    {
        switch ($PSCmdlet.ParameterSetName)
        {
            "HashTables"
            {
                $getSignatureBaseStringArgs=@{
                        OAuth=$OAuth;
                        Args=$Args;
                        Uri=$Uri;
                        Method=$Method;
                    }
                $signatureBaseString=Get-SignatureBaseString @getSignatureBaseStringArgs

                $getHmacSha1SignatureArgs=@{
                        SignatureBaseString=$signatureBaseString;
                        ConsumerSecret=$OAuth.consumer_secret;
                        TokenSecret="";
                    }

                if ($OAuth.Keys -contains "token_secret")
                {
                    $getHmacSha1SignatureArgs.TokenSecret = $OAuth.token_secret
                }

                Get-HmacSha1Signature @getHmacSha1SignatureArgs
            }

            "Normalized"
            {
                $getSignatureBaseStringArgs=@{
                        NormalizedRequestParameters=$NormalizedRequestParameters;
                        Uri=$Uri;
                        Method=$Method;
                    }
                $signatureBaseString=Get-SignatureBaseString @getSignatureBaseStringArgs

                $getHmacSha1SignatureArgs=@{
                        SignatureBaseString=$signatureBaseString;
                        ConsumerSecret=$ConsumerSecret;
                        TokenSecret=$TokenSecret;
                    }
                Get-HmacSha1Signature @getHmacSha1SignatureArgs
            }

            "BaseString"
            {
                $sha=[System.Security.Cryptography.KeyedHashAlgorithm]::Create("HMACSHA1")
                $sha.Key=[System.Text.Encoding]::UTF8.Getbytes("$($ConsumerSecret)&$($TokenSecret)")
                [Convert]::Tobase64String($sha.ComputeHash([System.Text.Encoding]::UTF8.Getbytes($SignatureBaseString)))
            }
        }
    }
}


#endregion

#region 5.4.1 Authorization Header

function Get-AuthorizationHeader
{
    [CmdletBinding()]
    param
    (
        [Parameter(Mandatory=$true, ParameterSetName='HashTables')]
        [Parameter(Mandatory=$true, ParameterSetName='Normalized')]
        [Parameter(Mandatory=$true, ParameterSetName='BaseString')]
        [Parameter(Mandatory=$true, ParameterSetName='Signature')]
        [Hashtable]$OAuth,

        [Parameter(Mandatory=$true, ParameterSetName='HashTables')]
        [Hashtable]$Args,
        
        [Parameter(Mandatory=$true, ParameterSetName='Normalized')]
        [string]$NormalizedRequestParameters,

        [Parameter(Mandatory=$true, ParameterSetName='HashTables')]
        [Parameter(Mandatory=$true, ParameterSetName='Normalized')]
        [Parameter(Mandatory=$true, ParameterSetName='BaseString')]
        [Parameter(Mandatory=$true, ParameterSetName='Signature')]
        [uri]$Uri,

        [Parameter(Mandatory=$true, ParameterSetName='HashTables')]
        [Parameter(Mandatory=$true, ParameterSetName='Normalized')]
        [Microsoft.PowerShell.Commands.WebRequestMethod]$Method,

        [Parameter(Mandatory=$true, ParameterSetName='BaseString')]
        [string]$SignatureBaseString,

        [Parameter(Mandatory=$true, ParameterSetName='Signature')]
        [string]$HmacSha1Signature
    )

    BEGIN
    {
        switch ($PSCmdlet.ParameterSetName)
        {
            "HashTables"
            {
                $getHmacSha1SignatureArgs=@{
                        OAuth=$OAuth;
                        Args=$Args;
                        Uri=$Uri; 
                        Method=$Method;
                    }
                $hmacSha1Signature=Get-HmacSha1Signature @getHmacSha1SignatureArgs

                $getAuthorizationHeaderArgs=@{
                        OAuth=$OAuth;
                        HmacSha1Signature=$hmacSha1Signature;
                        Uri=$Uri;
                    }
                Get-AuthorizationHeader @getAuthorizationHeaderArgs
            }

            "Normalized"
            {
                $getHmacSha1SignatureArgs=@{
                        NormalizedRequestParameters=$NormalizedRequestParameters;
                        Uri=$Uri;
                        Method=$Method;
                        ConsumerSecret=$OAuth.consumer_secret;
                        TokenSecret="";
                    }

                if ($OAuth.Keys -contains "token_secret")
                {
                    $getHmacSha1SignatureArgs.TokenSecret = $OAuth.token_secret
                }

                $hmacSha1Signature=Get-HmacSha1Signature @getHmacSha1SignatureArgs

                $getAuthorizationHeaderArgs=@{
                        OAuth=$OAuth;
                        HmacSha1Signature=$hmacSha1Signature;
                        Uri=$Uri;
                    }
                Get-AuthorizationHeader @getAuthorizationHeaderArgs
            }

            "BaseString"
            {
                $getHmacSha1SignatureArgs=@{
                        SignatureBaseString=$SignatureBaseString;
                        ConsumerSecret=$oauth.consumer_secret;
                        TokenSecret="";
                    }

                if ($OAuth.Keys -contains "token_secret")
                {
                    $getHmacSha1SignatureArgs.TokenSecret = $OAuth.token_secret
                }

                $hmacSha1Signature=Get-HmacSha1Signature @getHmacSha1SignatureArgs

                $getAuthorizationHeaderArgs=@{
                        OAuth=$OAuth;
                        HmacSha1Signature=$hmacSha1Signature;
                        Uri=$Uri;
                    }
                Get-AuthorizationHeader @getAuthorizationHeaderArgs
            }

            "Signature"
            {
                $header="OAuth realm=""$($Uri.AbsoluteUri)"""
                $all=$OAuth.Clone();
                $all.Add("signature", $HmacSha1Signature)
                foreach ($key in $all.Keys |?{ !$_.ToLower().EndsWith("_secret") } | Sort-Object)
                {
                    $header += ",`r`n                oauth_$($key.ToLower())=""$([uri]::EscapeDataString($all[$key]))"""
                }
                $header
            }
        }
    }
}


#endregion

#region Testing

function Write-TestResult
{
    [CmdletBinding()]
    param
    (
        [Parameter(Mandatory=$true)]
        [string]$Test,

        [Parameter(Mandatory=$true)]
        [string]$Expected,

        [Parameter(Mandatory=$true)]
        [string]$Actual

    )

    BEGIN
    {
        Write-Host -NoNewline "Testing $Test`: "
        if ($Expected -eq $Actual)
        {
            Write-Host -ForegroundColor Green "Pass"
        }
        else
        {
            Write-Host -ForegroundColor Red "Fail"
            Write-Host "Expected:"
            Write-Host $expected
            Write-Host "Actual:"
            Write-Host $actual
        }
    }
}

function Test-OAuthFunctions
{
    $oauth=@{
            consumer_key="dpf43f3p2l4k3l03";
            consumer_secret="kd94hf93k423kf44";
            nonce="kllo9940pd9333jh";
            signature_method="HMAC-SHA1";
            timestamp=1191242096;
            version="1.0";
            token="nnch734d00sl2jdk";
            token_secret="pfkkdhi9sl3r4s00";
        }

    $args=@{
            file="vacation.jpg";
            size="original";
        }

    $uri="http://photos.example.net/photos"

    $method="GET"


    #region Get-NormalizedRequestParameters

    $normalizedRequestParametersEx="file=vacation.jpg&oauth_consumer_key=dpf43f3p2l4k3l03&oauth_nonce=kllo9940pd9333jh&oauth_signature_method=HMAC-SHA1&oauth_timestamp=1191242096&oauth_token=nnch734d00sl2jdk&oauth_version=1.0&size=original"

    Write-TestResult -Test "Get-NormalizedRequestParameters (HashTables)" -Expected $normalizedRequestParametersEx -Actual (Get-NormalizedRequestParameters -OAuth $oauth -Args $args)

    #endregion

    #region Get-SignatureBaseString

    $signatureBaseStringEx="GET&http%3A%2F%2Fphotos.example.net%2Fphotos&file%3Dvacation.jpg%26oauth_consumer_key%3Ddpf43f3p2l4k3l03%26oauth_nonce%3Dkllo9940pd9333jh%26oauth_signature_method%3DHMAC-SHA1%26oauth_timestamp%3D1191242096%26oauth_token%3Dnnch734d00sl2jdk%26oauth_version%3D1.0%26size%3Doriginal"

    Write-TestResult -Test "Get-SignatureBaseString (HashTables)" -Expected $signatureBaseStringEx -Actual (Get-SignatureBaseString -OAuth $oauth -Args $args -Uri $uri -Method $method)
    Write-TestResult -Test "Get-SignatureBaseString (Normalized)" -Expected $signatureBaseStringEx -Actual (Get-SignatureBaseString -NormalizedRequestParameters $normalizedRequestParametersEx -Uri $uri -Method $method)

    #endregion

    #region Get-HmacSha1Signature

    $hmacSha1SignatureEx="tR3+Ty81lMeYAr/Fid0kMTYa/WM="

    Write-TestResult -Test "Get-HmacSha1Signature (HashTables)" -Expected $hmacSha1SignatureEx -Actual (Get-HmacSha1Signature -OAuth $oauth -Args $args -Uri $uri -Method $method)
    Write-TestResult -Test "Get-HmacSha1Signature (Normalized)" -Expected $hmacSha1SignatureEx -Actual (Get-HmacSha1Signature -NormalizedRequestParameters $normalizedRequestParametersEx -Uri $uri -Method $method -ConsumerSecret $oauth.consumer_secret -TokenSecret $oauth.token_secret)
    Write-TestResult -Test "Get-HmacSha1Signature (BaseString)" -Expected $hmacSha1SignatureEx -Actual (Get-HmacSha1Signature -SignatureBaseString $signatureBaseStringEx -ConsumerSecret $oauth.consumer_secret -TokenSecret $oauth.token_secret)

    #endregion

    #region Get-AuthorizationHeader

    $authorizationHeaderEx=@"
OAuth realm="http://photos.example.net/photos",
                oauth_consumer_key="dpf43f3p2l4k3l03",
                oauth_nonce="kllo9940pd9333jh",
                oauth_signature="tR3%2BTy81lMeYAr%2FFid0kMTYa%2FWM%3D",
                oauth_signature_method="HMAC-SHA1",
                oauth_timestamp="1191242096",
                oauth_token="nnch734d00sl2jdk",
                oauth_version="1.0"
"@

    Write-TestResult -Test "Get-AuthorizationHeader (HashTables)" -Expected $authorizationHeaderEx -Actual (Get-AuthorizationHeader -OAuth $oauth -Args $args -Uri $uri -Method $method)
    Write-TestResult -Test "Get-AuthorizationHeader (Normalized)" -Expected $authorizationHeaderEx -Actual (Get-AuthorizationHeader -OAuth $oauth -NormalizedRequestParameters $normalizedRequestParametersEx -Uri $uri -Method $method)
    Write-TestResult -Test "Get-AuthorizationHeader (BaseString)" -Expected $authorizationHeaderEx -Actual (Get-AuthorizationHeader -OAuth $oauth -Uri $uri -SignatureBaseString $signatureBaseStringEx)
    Write-TestResult -Test "Get-AuthorizationHeader (Signature)" -Expected $authorizationHeaderEx -Actual (Get-AuthorizationHeader -OAuth $oauth -Uri $uri -HmacSha1Signature $hmacSha1SignatureEx)

    #endregion

}

#endregion

#region Invocation

function Invoke-OAuthRequest
{
    [CmdletBinding()]
    param
    (
        [Parameter(Mandatory=$true, ParameterSetName='Relative')]
        [uri]$BaseUri,
        
        [Parameter(Mandatory=$true, ParameterSetName='Relative')]
        [uri]$RelativeUri,
        
        [Parameter(Mandatory=$true, ParameterSetName='Absolute')]
        [uri]$Uri,
        
        [Parameter(Mandatory=$true)]
        [string]$ConsumerKey,

        [Parameter(Mandatory=$true)]
        [string]$ConsumerSecret,
        
        [Parameter()]
        [string]$TokenKey,

        [Parameter()]
        [string]$TokenSecret,

        [Parameter()]
        [Microsoft.PowerShell.Commands.WebRequestMethod]$Method = "GET",

        [Parameter()]
        [System.Net.SecurityProtocolType]$SecurityProtocol = "Tls12",

        [Parameter()]
        [hashtable]$Args = @{},

        [Parameter()]
        [Switch]$QueryDecode,

        [Parameter()]
        [Switch]$JsonDecode

    )

    BEGIN
    {
        switch ($PSCmdlet.ParameterSetName)
        {
            "Relative"
            {
                $invokeOAuthRequestArgs=@{
                        Uri=[uri]::New($BaseUri, $RelativeUri);
                        ConsumerKey=$ConsumerKey;
                        ConsumerSecret=$ConsumerSecret;
                        TokenKey=$TokenKey;
                        TokenSecret=$TokenSecret;
                        Method=$Method;
                        SecurityProtocol=$SecurityProtocol;
                        Args=$Args;
                        QueryDecode=$QueryDecode;
                        JsonDecode=$JsonDecode;
                    }
                Invoke-OAuthRequest @invokeOAuthRequestArgs
            }

            "Absolute"
            {
                $oauth=@{
                        consumer_key="$($ConsumerKey)";
                        consumer_secret ="$($ConsumerSecret)";
                        nonce=-join ((65..90) + (97..122) | Get-Random -Count 80 | % {[char]$_});
                        signature_method="HMAC-SHA1";
                        timestamp=[Math]::Floor([decimal](Get-Date(Get-Date).ToUniversalTime()-uformat "%s"));
                        version="1.0";
                    }

                if ($TokenKey -ne $null -and $TokenKey -ne "" -and $TokenSecret -ne $null -and $TokenSecret -ne "")
                {
                    $oauth.Add("token", $TokenKey)
                    $oauth.Add("token_secret", $TokenSecret)
                }

                $authorizationHeader = Get-AuthorizationHeader -OAuth $oauth -Args $Args -Uri $Uri -Method $Method

                $invokeWebRequestArgs = @{
                        Uri=$Uri;
                        Method=$Method;
                        Headers=@{ Authorization=$authorizationHeader };
                    }
                
                if ($Args.Count -gt 0)
                {
                    switch ($Method)
                    {
                        "Get"
                        {
                            $uriBuilder = [System.UriBuilder]::new($Uri)
                            $uriBuilder.Query = [string]::Join("&", ($Args.GetEnumerator() |%{ "$($_.Name)=$($_.Value)" }))
                            $invokeWebRequestArgs.Uri = $uriBuilder.Uri
                        }

                        default
                        {
                            Write-Error "Arguments with method $($Method) not yet implemented"
                        }
                    }
                }

                try
                {
                    $oldSecurityProtocol=[Net.ServicePointManager]::SecurityProtocol
                    [Net.ServicePointManager]::SecurityProtocol=$SecurityProtocol
                    $response = (Invoke-WebRequest @invokeWebRequestArgs)
                    [Net.ServicePointManager]::SecurityProtocol=$oldSecurityProtocol
                }
                catch
                {
                    $response = [PSCustomObject]@{ StatusCode = $_ }
                }

                if ($response.StatusCode -ne 200)
                {
                    Write-Error $response.StatusCode
                    
                }
                else
                {
                    if ($QueryDecode -and $JsonDecode)
                    {
                        Write-Error "Cannot specify both QueryDecode and JsonDecode"
                    }

                    if ($QueryDecode -and !$JsonDecode)
                    {
                        $result = @{}
                        $response.Content.Split("&") |%{ $result.Add($_.Split("=")[0], $_.Split("=")[1]) }
                        [PSCustomObject]$result
                    }

                    if (!$QueryDecode -and $JsonDecode)
                    {
                        $response.Content | ConvertFrom-Json
                    }

                    if (!$QueryDecode -and !$JsonDecode)
                    {
                        $response.Content
                    }
                }
            }
        }
    }
}

#endregion
