﻿function Get-ResultFromCacheOrFunction
{
    [Alias("CacheResult")]
    [CmdletBinding()]
    param
    (
        [Parameter(Mandatory=$true, Position=1)]
        [string]$CachePath,

        [Parameter(Mandatory=$true, Position=2)]
        [ScriptBlock]$ScriptBlock,

        [Parameter()]
        [int]$Retention=1440,

        [Parameter()]
        [switch]$NoExpiry,

        [Parameter()]
        [switch]$NoCache
    )

    BEGIN
    {
        if ((Test-Path $CachePath) -and ($NoCache -or (!$NoExpiry -and $Retention -gt 0 -and ((Get-Item -Path $CachePath).Length -eq 0 -or ((Get-Date) - (Get-Item -Path $CachePath).LastWriteTime).TotalMinutes -gt $Retention))))
        {
            Remove-Item -Path $CachePath
        }

        if (!(Test-Path $CachePath))
        {
            Invoke-Command -ScriptBlock $ScriptBlock | ConvertTo-Json -Depth 100 | Out-File -FilePath $CachePath
        }

        Get-Content -Path $CachePath | Out-String | ConvertFrom-Json
    }
}

function Get-TimeZoneMap
{
    [CmdletBinding()]
    param
    (
        [Parameter(ParameterSetName="Windows")]
        [Parameter(ParameterSetName="IANA")]
        [Parameter(ParameterSetName="Unfiltered")]
        $CachePath=(Join-Path -Path (New-Item -ItemType Directory -Force -Path (Join-Path -Path $env:LOCALAPPDATA -ChildPath "TimeZoneMapPs")).FullName -ChildPath "timezonemap.json"),

        [Parameter(Mandatory = $true, ParameterSetName="Windows")]
        [string]$Windows,

        [Parameter(Mandatory = $true, ParameterSetName="IANA")]
        [string]$IANA
    )

    BEGIN
    {
        $zones = (CacheResult $CachePath { Get-TimeZoneMapEx } | Convert-XmlToMapZone)

        switch ($PSCmdlet.ParameterSetName)
        {
            "Windows"
            {
                $zones |?{ $_.Windows -like $Windows }
            }
            "IANA"
            {
                $zones |?{ $_.IANA -like $IANA }
            }
            "Unfiltered"
            {
                $zones
            }
        }
    }
}

function Get-TimeZoneMapEx
{
    [CmdletBinding()]
    param
    (
        [Parameter()]
        [uri]$Uri = "https://unicode.org/repos/cldr/trunk/common/supplemental/windowsZones.xml",

        [Parameter()]
        [System.Net.SecurityProtocolType]$SecurityProtocol = "Tls12"
    )

    BEGIN
    {
        try
        {
            $oldSecurityProtocol=[Net.ServicePointManager]::SecurityProtocol
            [Net.ServicePointManager]::SecurityProtocol=$SecurityProtocol
            $response = (Invoke-WebRequest -Uri $Uri)
            [Net.ServicePointManager]::SecurityProtocol=$oldSecurityProtocol
        }
        catch
        {
            $response = [PSCustomObject]@{ StatusCode = $_ }
        }

        if ($response.StatusCode -ne 200)
        {
            Write-Error $response.StatusCode
                    
        }
        else
        {
            $response.Content
        }
    }
}

filter Convert-XmlToMapZone
{
    foreach ($mapZone in ([xml]$_).supplementalData[1].windowsZones.mapTimezones.mapZone |?{ $_.territory -ne "001" })
    {
        foreach ($type in $mapZone.type.split(" "))
        {
            [PSCustomObject]@{
                Windows=$mapZone.other;
                IANA=$type;
                Territory=$mapZone.territory;
            }
        }
    }
}