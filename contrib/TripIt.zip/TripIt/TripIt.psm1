#https://stackoverflow.com/questions/20886243/press-any-key-to-continue
function Start-Pause ($message)
{
    # Check if running Powershell ISE
    if ($psISE)
    {
        Add-Type -AssemblyName System.Windows.Forms
        [System.Windows.Forms.MessageBox]::Show("$message")
    }
    else
    {
        Write-Host "$message" -ForegroundColor Yellow
        $x = $host.ui.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    }
}


function Get-ResultFromCacheOrFunction
{
    [Alias("CacheResult")]
    [CmdletBinding()]
    param
    (
        [Parameter(Mandatory=$true, Position=1)]
        [string]$ProfilePath,

        [Parameter(Mandatory=$true, Position=2)]
        [AllowNull()]
        [AllowEmptyString()]
        [string]$CacheName,

        [Parameter(Mandatory=$true, Position=3)]
        [ScriptBlock]$ScriptBlock,

        [Parameter()]
        [int]$Retention=1440,

        [Parameter()]
        [switch]$NoExpiry,

        [Parameter()]
        [switch]$NoCache
    )

    BEGIN
    {
        $path = $ProfilePath

        if ($CacheName -ne $null -and $CacheName -ne "")
        {
            $path = (Join-Path -Path (New-Item -ItemType Directory -Force -Path (Join-Path -Path (Split-Path $ProfilePath) -ChildPath (Get-TripItProfile).PrimaryEmail)).FullName -ChildPath "$($CacheName).json")
        }

        if ((Test-Path $path) -and ($NoCache -or (!$NoExpiry -and $Retention -gt 0 -and ((Get-Item -Path $path).Length -eq 0 -or ((Get-Date) - (Get-Item -Path $path).LastWriteTime).TotalMinutes -gt $Retention))))
        {
            Remove-Item -Path $path
        }

        if (!(Test-Path $path))
        {
            Invoke-Command -ScriptBlock $ScriptBlock | ConvertTo-Json -Depth 100 | Out-File -FilePath $path
        }

        Get-Content -Path $path | Out-String | ConvertFrom-Json
    }
}

function Get-TripItProfilePath
{
    (Join-Path -Path (New-Item -ItemType Directory -Force -Path (Join-Path -Path $env:LOCALAPPDATA -ChildPath "TripItPs")).FullName -ChildPath "profile.json")
}

function Get-TripItProfileToken
{
    $result = @{}
    (Get-TripItProfile).Token.PSObject.Properties |%{ $result[$_.Name] = $_.Value }
    $result
}

function Get-TripItProfileEx
{
    [CmdletBinding()]
    param
    (
        [Parameter()]
        [uri]$BaseUri,

        [Parameter()]
        [string]$ConsumerSecret,

        [Parameter()]
        [string]$ConsumerKey,

        [Parameter()]
        [string]$Callback
    )
    BEGIN
    {
        $token = @{
                ConsumerSecret=$ConsumerSecret;
                ConsumerKey=$ConsumerKey;
                Tokenkey="";
                TokenSecret="";
                BaseUri=$BaseUri;
            }

        $unauthorizedAccessToken = [PSCustomObject](Invoke-OAuthRequest @token -Method POST -RelativeUri "/oauth/request_token" -QueryDecode)

        $token.TokenKey = $unauthorizedAccessToken.oauth_token
        $token.TokenSecret = $unauthorizedAccessToken.oauth_token_secret

        [Diagnostics.Process]::Start("https://www.tripit.com/oauth/authorize?oauth_token=$($unauthorizedAccessToken.oauth_token)&oauth_callback=$([uri]::EscapeDataString($Callback))") | Out-Null

        Start-Pause "TripIt will now open in your default web browser to authorize token ""$($unauthorizedAccessToken.oauth_token)"". Please complete the authorization process and press OK once complete." | Out-Null

        $authorizedAccessToken = [PSCustomObject](Invoke-OAuthRequest @token -Method POST -RelativeUri "/oauth/access_token" -QueryDecode)

        $token.TokenKey = $authorizedAccessToken.oauth_token
        $token.TokenSecret = $authorizedAccessToken.oauth_token_secret

        $profile = (Invoke-OAuthRequest @token -RelativeUri "/v1/get/profile" -Args @{ format="json" } -JsonDecode).Profile

        @{
            PrimaryEmail=@($profile.ProfileEmailAddresses.ProfileEmailAddress |?{ $_.is_primary -eq "true" })[0].Address;
            Profile=$profile;
            Token=$token;
            ScreenName=$profile.screen_name;
            DisplayName=$profile.public_display_name;
        }
    }
}

function Get-TripItProfile
{
    [CmdletBinding()]
    param
    (
        [Parameter()]
        [uri]$BaseUri="https://api.tripit.com",

        [Parameter()]
        [string]$ConsumerSecret="fee7133436bfc6dfb8d33079c7fa7954ee543e12",

        [Parameter()]
        [string]$ConsumerKey="a831ebee0856158793aaaf6e6738876dacd2392e",

        [Parameter()]
        [string]$Callback="http://fiftyeight.us/callback.html",

        [Parameter()]
        [string]$ProfilePath=(Get-TripItProfilePath)
    )
    BEGIN
    {
        CacheResult $ProfilePath $null -NoExpiry {
            $getTripItProfileExArgs = @{
                BaseUri=$BaseUri;
                ConsumerSecret=$ConsumerSecret;
                ConsumerKey=$ConsumerKey;
                Callback=$Callback;
            }
            
            Get-TripItProfileEx @getTripItProfileExArgs
        }
    }
}

function Get-Trip
{
    [CmdletBinding()]
    param
    (
        [Parameter()]
        [string]$ProfilePath=(Get-TripItProfilePath),

        [Parameter()]
        [uri]$MobileBaseUri="http://m.tripit.com",

        [Parameter()]
        [uri]$DesktopBaseUri="http://www.tripit.com",

        [Parameter()]
        [int]$TripId,

        [Parameter()]
        [DateTime]$Date,

        [Parameter()]
        [Bool]$Past,

        [Parameter()]
        [string]$Name,

        [Parameter()]
        [string]$Location,

        [Parameter()]
        [switch]$NoCache
    )

    BEGIN
    {
        (CacheResult $ProfilePath "trips" -NoCache:$NoCache {
            Get-TripEx
        })|%{
            [PSCustomObject]@{
                TripId=[int]$_.id;
                Start=[System.DateTime]::Parse($_.start_date);
                End=[System.DateTime]::Parse($_.end_date);
                Past=([System.DateTimeOffset]::new(
                    [System.DateTime]::Parse($_.end_date), 
                    [System.TimeZoneInfo]::FindSystemTimeZoneById("Pacific Standard Time").GetUtcOffset([System.DateTime]::Parse($_.end_date))).AddDays(1).LocalDateTime -lt [System.DateTime]::Now)
                Name=[string]$_.display_name;
                Location=[string]$_.primary_location;
                MobileUri=[uri]::New($MobileBaseUri, $_.relative_url);
                DesktopUri=[uri]::New($DesktopBaseUri, $_.relative_url);
            }   
        }|?{
           (!$PSBoundParameters.ContainsKey('TripId') -or ($PSBoundParameters.ContainsKey('TripId') -and $_.TripId -eq $TripId)) -and
           (!$PSBoundParameters.ContainsKey('Date') -or ($PSBoundParameters.ContainsKey('Date') -and $_.Start -le $Date -and $_.End -ge $Date)) -and
           (!$PSBoundParameters.ContainsKey('Past') -or ($PSBoundParameters.ContainsKey('Past') -and $_.Past -eq $Past)) -and
           (!$PSBoundParameters.ContainsKey('Name') -or ($PSBoundParameters.ContainsKey('Name') -and $_.Name -like $Name)) -and
           (!$PSBoundParameters.ContainsKey('Location') -or ($PSBoundParameters.ContainsKey('Location') -and $_.Location -like $Location))
        } | Sort-Object {$_.Start}
    }
}

function Get-TripEx
{
    [CmdletBinding(DefaultParameterSetName='Unfiltered')]
    param
    (
        [Parameter(ParameterSetName='Unfiltered')]
        [Parameter(ParameterSetName='Filtered')]
        [HashTable]$Token=(Get-TripItProfileToken),

        [Parameter(ParameterSetName='Filtered')]
        [bool]$Past,

        [Parameter(ParameterSetName='Filtered')]
        [int]$PageNum=1,

        [Parameter(ParameterSetName='Filtered')]
        [int]$PageSize=10
    )
    
    PROCESS
    {
        switch ($PSCmdlet.ParameterSetName)
        {
            "Unfiltered"
            {
                foreach ($past in @($true, $false))
                {
                    $getTripExArgs = @{
                            Token=$Token;
                            Past=$Past;
                        }
                    Get-TripEx @getTripExArgs
                }
            }

            "Filtered"
            {
                $result = Invoke-OAuthRequest @Token -RelativeUri "/v1/list/trip/past/$($Past.ToString().ToLower())" -Args @{ format="json"; page_num=$PageNum; page_size=$PageSize } -JsonDecode
                $result.Trip
                
                if ($result.max_page -ne $PageNum)
                {
                    $getTripExArgs = @{
                            Token=$Token;
                            Past=$Past;
                            PageNum=$PageNum + 1;
                            PageSize=$PageSize;
                        }
                    Get-TripEx @getTripExArgs
                }
            }
        }
    }
}


function Get-Air
{
    [CmdletBinding()]
    param
    (
        [Parameter()]
        [string]$ProfilePath=(Get-TripItProfilePath),

        [Parameter()]
        [uri]$MobileBaseUri="http://m.tripit.com",

        [Parameter()]
        [uri]$DesktopBaseUri="http://www.tripit.com",

        [Parameter(Mandatory=$true, ValueFromPipelineByPropertyName=$true)]
        [int]$TripId,

        [Parameter()]
        [switch]$NoCache
    )

    PROCESS
    {
        foreach ($air in (CacheResult $ProfilePath "$($TripId).air" -NoCache:$NoCache { Get-AirEx -TripId $TripId }))
        {
            $trip = Get-Trip -TripId $air.trip_id
            foreach ($segment in $air.Segment)
            {
                $startDateTime=[System.DateTimeOffset]::new(
                    [System.DateTime]::Parse("$($segment.StartDateTime.date) $($segment.StartDateTime.time)"), 
                    [System.TimeZoneInfo]::FindSystemTimeZoneById((Get-TimeZoneMap -IANA $segment.StartDateTime.timezone).Windows).GetUtcOffset([System.DateTime]::Parse("$($segment.StartDateTime.date) $($segment.StartDateTime.time)")))
                
                $finishDateTime=[System.DateTimeOffset]::new(
                    [System.DateTime]::Parse("$($segment.EndDateTime.date) $($segment.EndDateTime.time)"), 
                    [System.TimeZoneInfo]::FindSystemTimeZoneById((Get-TimeZoneMap -IANA $segment.EndDateTime.timezone).Windows).GetUtcOffset([System.DateTime]::Parse("$($segment.EndDateTime.date) $($segment.EndDateTime.time)")))

                $duration = $finishDateTime - $startDateTime;
                $flight = "$($segment.marketing_airline_code)$($segment.marketing_flight_number)"

                if ($duration.ToString("%h\h\,\ mm\m") -ne $segment.duration)
                {
                    Write-Warning "$($TripId) $($air.supplier_conf_num) $($segment.start_airport_code)-$($segment.end_airport_code) air segment duration '$($segment.duration)' does not match calculated duration '$($duration.ToString("%h\h\,\ mm\m")) ($([System.Uri]::new($DesktopBaseUri, $air.relative_url)))'"
                }

                [PSCustomObject]@{
                    Flight=$flight;
                    Start=$startDateTime;
                    Finish=$finishDateTime;
                    
                    SupplierConfirmationNumber=$air.supplier_conf_num;
                    BookingSiteConfirmationNumber=$air.booking_site_conf_num;
                    AgencyConfirmationNumber=$air.Agency.agency_conf_num;
                    TicketNumber=$air.Traveler.ticket_num;
                    
                    Trip=$trip.Name;
                    Origin=$segment.start_airport_code;
                    Destination=$segment.end_airport_code;
                    Duration=$duration;
                    Aircraft=$segment.aircraft;
                    Seats=$segment.Seats;
                }
            }   
        }
    }
}


function Get-AirEx
{
    [CmdletBinding(DefaultParameterSetName='Unfiltered')]
    param
    (
        [Parameter(ParameterSetName='Unfiltered', Mandatory=$true)]
        [Parameter(ParameterSetName='Filtered', Mandatory=$true)]
        [int]$TripId,
        
        [Parameter(ParameterSetName='Unfiltered')]
        [Parameter(ParameterSetName='Filtered')]
        [HashTable]$Token=(Get-TripItProfileToken),

        [Parameter(ParameterSetName='Filtered')]
        [bool]$Past,

        [Parameter(ParameterSetName='Filtered')]
        [int]$PageNum=1,

        [Parameter(ParameterSetName='Filtered')]
        [int]$PageSize=10
    )
    
    BEGIN
    {
        switch ($PSCmdlet.ParameterSetName)
        {
            "Unfiltered"
            {
                foreach ($past in @($true, $false))
                {
                    $getAirExArgs = @{
                            TripId=$TripId;
                            Token=$Token;
                            Past=$Past;
                        }
                    Get-AirEx @getAirExArgs
                }
            }

            "Filtered"
            {
                $result = Invoke-OAuthRequest @Token -RelativeUri "/v1/list/object/type/air/past/$($Past.ToString().ToLower())/trip_id/$($TripId)" -Args @{ format="json"; page_num=$PageNum; page_size=$PageSize } -JsonDecode
                
                if ($result.PSobject.Properties.Name -contains "AirObject")
                {
                    $result.AirObject
                }
                
                if ($result.max_page -ne $PageNum)
                {
                    $getAirExArgs = @{
                            TripId=$TripId;
                            Token=$Token;
                            Past=$Past;
                            PageNum=$PageNum + 1;
                            PageSize=$PageSize;
                            
                        }
                    Get-AirEx @getAirExArgs
                }
            }
        }
    }
}